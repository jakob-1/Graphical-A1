﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class transformTest : MonoBehaviour {

    public IGB283Transform T;
    public Transform otherSquare;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

	}
}
